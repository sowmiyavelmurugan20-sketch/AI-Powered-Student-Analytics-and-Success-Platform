export interface StudentProfile {
  id: string;
  name: string;
  title: string;
  firstName: string;
  lastName: string;
  status: 'Active' | 'Inactive' | 'On Leave';
  admissionNo: string;
  admissionYear: string;
  rollNo: string;
  degree: string;
  department: string;
  courseName: string;
  college: string;
  semester: string;
  section: string;
  academicYear: string;
  curriculumPlan: string;
  academicStanding: string;
  academicClassification: string;
  discountCategory: string;
  intake: string;
  programValidityDate: string;
  dob: string;
  age: number;
  gender: 'Female' | 'Male' | 'Other';
  fatherName: string;
  motherName: string;
  address: string;
  city: string;
  state: string;
  country: string;
  email: string;
  phone: string;
  avatarUrl: string;
  collegeLogoUrl: string;
  bloodGroup: string;
  mentorName: string;
  mentorCabin: string;
}

export interface SubjectGrade {
  code: string;
  name: string;
  credits: number;
  type: 'Theory' | 'Practical' | 'Integrated';
  faculty: string;
  cia1: number;
  cia2: number;
  modelExam: number;
  internalTotal: number;
  predictedGrade: 'O' | 'A+' | 'A' | 'B+' | 'B' | 'RA';
  status: 'Passed' | 'In Progress' | 'Arrear';
}

export interface SemesterRecord {
  semester: string;
  academicYear: string;
  sgpa: number;
  creditsRegistered: number;
  creditsEarned: number;
  status: 'Completed' | 'Current';
  subjects: SubjectGrade[];
}

export interface SubjectAttendance {
  code: string;
  name: string;
  faculty: string;
  conducted: number;
  attended: number;
  odApproved: number;
  percentage: number;
  requiredClassesTo75: number;
  canBunkClasses: number;
  status: 'Safe' | 'Warning' | 'Critical';
}

export interface AttendanceRecord {
  overallPercentage: number;
  totalConducted: number;
  totalAttended: number;
  totalOd: number;
  minimumRequired: number;
  subjectWise: SubjectAttendance[];
  recentLogs: {
    date: string;
    day: string;
    periods: { period: number; subject: string; status: 'Present' | 'Absent' | 'OD' }[];
  }[];
}

export interface Assignment {
  id: string;
  courseCode: string;
  courseName: string;
  title: string;
  dueDate: string;
  points: number;
  status: 'Submitted' | 'Pending' | 'Evaluated';
  score?: number;
  feedback?: string;
  submissionDate?: string;
}

export interface LMSCourse {
  code: string;
  name: string;
  faculty: string;
  progressPercentage: number;
  materialsCount: number;
  assignmentsPending: number;
  lastAccessed: string;
}

export interface PlacementMetric {
  aptitudeScore: number;
  codingScore: number;
  verbalScore: number;
  mockInterviewScore: number;
  readinessRating: 'High' | 'Moderate' | 'Developing';
  codingProfiles: { platform: string; rating: string; solved: number }[];
  targetCompanies: {
    company: string;
    role: string;
    packageLpa: string;
    criteriaMet: boolean;
    tier: 'Dream' | 'Super Dream' | 'Core';
  }[];
  interviewRemarks: {
    interviewer: string;
    date: string;
    verdict: string;
    notes: string;
  }[];
}

export interface SkillItem {
  name: string;
  category: 'Technical' | 'Soft Skills' | 'Domain';
  proficiency: number; // 0 - 100
  verifiedBy: string;
}

export interface Certification {
  id: string;
  title: string;
  issuer: string;
  issueDate: string;
  credentialId: string;
  badgeType: 'Elite' | 'Gold' | 'Standard';
  category: 'Cloud' | 'Data' | 'Programming' | 'Management';
}

export interface StudentSegment {
  id: string;
  name: string;
  criteria: string;
  description: string;
  colorTheme: string;
  studentCountInCollege: number;
  interventionPlan: string[];
  recommendedAction: string;
  currentStudentBelongs: boolean;
}
