import React from 'react';
import { 
  Award, 
  CheckCircle2, 
  ExternalLink, 
  Sparkles, 
  Users2, 
  Trophy, 
  ShieldCheck, 
  Layers
} from 'lucide-react';
import { SkillItem, Certification } from '../types/student';
import { engagementActivities } from '../data/studentData';

interface SkillsSectionProps {
  skills: SkillItem[];
  certifications: Certification[];
}

export const SkillsSection: React.FC<SkillsSectionProps> = ({ skills, certifications }) => {
  const technicalSkills = skills.filter(s => s.category === 'Technical');
  const softAndDomainSkills = skills.filter(s => s.category !== 'Technical');

  return (
    <div className="space-y-6">
      {/* Top Skills Headline Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Verified Certifications
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-blue-700">
              {certifications.length}
            </span>
            <span className="text-xs text-slate-500 font-medium">Badges</span>
          </div>
          <div className="mt-2 text-xs text-emerald-700 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            NPTEL & AWS Verified
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Technical Skill Index
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              88.5%
            </span>
            <span className="text-xs text-slate-500 font-medium">Proficiency</span>
          </div>
          <div className="mt-2 text-xs text-slate-600 font-medium">
            Assessed across 8 Competencies
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Hackathons & Conclaves
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600">
              3
            </span>
            <span className="text-xs text-slate-500 font-medium">Podiums</span>
          </div>
          <div className="mt-2 text-xs text-emerald-700 font-semibold flex items-center gap-1">
            <Trophy className="w-3.5 h-3.5" />
            Smart India Hackathon Finalist
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Leadership & Clubs
          </div>
          <div className="mt-1 text-lg sm:text-xl font-bold text-slate-900">
            GDSC Core Lead
          </div>
          <div className="mt-2 text-xs text-blue-700 font-semibold">
            Google Developer Student Clubs
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Technical Competencies Card */}
        <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-600" />
            Core Technical Skill Competencies
          </h3>

          <div className="space-y-3.5 text-xs">
            {technicalSkills.map((s) => (
              <div key={s.name}>
                <div className="flex justify-between items-baseline mb-1">
                  <div>
                    <span className="font-semibold text-slate-800">{s.name}</span>
                    <span className="text-[11px] text-slate-400 ml-2">({s.verifiedBy})</span>
                  </div>
                  <span className="font-mono font-bold text-slate-900">{s.proficiency}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all" 
                    style={{ width: `${s.proficiency}%` }} 
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Soft Skills & Business Systems */}
        <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            Business Systems & Soft Skill Assessments
          </h3>

          <div className="space-y-3.5 text-xs">
            {softAndDomainSkills.map((s) => (
              <div key={s.name}>
                <div className="flex justify-between items-baseline mb-1">
                  <div>
                    <span className="font-semibold text-slate-800">{s.name}</span>
                    <span className="text-[11px] text-slate-400 ml-2">({s.verifiedBy})</span>
                  </div>
                  <span className="font-mono font-bold text-slate-900">{s.proficiency}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-emerald-600 h-2 rounded-full transition-all" 
                    style={{ width: `${s.proficiency}%` }} 
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-600">
            <span className="font-bold text-slate-900">Industry Mentor Remark:</span> Outstanding combination of Computer Science foundations and Business Process modeling acumen.
          </div>
        </div>
      </div>

      {/* Verified Certifications Section */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-50/60 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Industry & NPTEL Autonomous Certifications
            </h3>
            <p className="text-xs text-slate-500">
              Verified by Excel Autonomous Exam Cell for credit waivers and honors.
            </p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 bg-white rounded-md border border-slate-200 text-slate-700">
            Credit Transfer Eligible
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-100 text-xs">
          {certifications.map((cert) => (
            <div key={cert.id} className="p-4 space-y-2 hover:bg-slate-50/70 transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm leading-snug">{cert.title}</h4>
                  <div className="text-slate-600 font-medium">{cert.issuer}</div>
                </div>
                <span className="font-semibold text-[11px] px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                  {cert.badgeType}
                </span>
              </div>

              <div className="flex items-center justify-between pt-1 text-[11px] text-slate-500">
                <span className="font-mono">ID: {cert.credentialId}</span>
                <span>Issued: {cert.issueDate}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Extracurricular Clubs & Hackathons */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Users2 className="w-4 h-4 text-slate-700" />
          Campus Engagement, Hackathons & Professional Societies
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {engagementActivities.map((act) => (
            <div key={act.title} className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1 text-xs">
              <div className="text-[11px] text-blue-700 font-semibold">{act.category}</div>
              <div className="font-bold text-slate-900">{act.title}</div>
              <div className="text-slate-600 font-medium">{act.role}</div>
              <div className="text-[11px] text-slate-400 font-mono pt-1">{act.tenure}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
