import React from 'react';
import { StudentProfile, SemesterRecord } from '../types/student';
import { X, Printer } from 'lucide-react';

interface PrintGradeCardProps {
  student: StudentProfile;
  records: SemesterRecord[];
  onClose: () => void;
}

export const PrintGradeCard: React.FC<PrintGradeCardProps> = ({
  student,
  records,
  onClose
}) => {
  const handlePrint = () => {
    window.print();
  };

  const currentRecord = records.find(r => r.semester === student.semester) || records[records.length - 1];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full border border-slate-300 p-6 sm:p-8 space-y-6 my-8 animate-in zoom-in-95 duration-150">
        {/* Action Header - Hidden during print */}
        <div className="flex items-center justify-between border-b border-slate-200 pb-3 no-print">
          <div>
            <h3 className="font-bold text-slate-900 text-sm">Official Autonomous Grade Transcript Preview</h3>
            <p className="text-xs text-slate-500">Formatted for standard A4 institutional print / PDF archive.</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg border border-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Official Document */}
        <div className="border border-slate-300 p-6 bg-white space-y-6 text-xs text-slate-900">
          {/* Institutional Top Crest Header */}
          <div className="text-center border-b-2 border-slate-800 pb-4 space-y-1">
            <h1 className="text-base sm:text-lg font-extrabold uppercase tracking-tight text-slate-950">
              {student.college}
            </h1>
            <p className="text-[11px] font-semibold text-slate-700">
              (An Autonomous Institution · Approved by AICTE, New Delhi · Affiliated to Anna University)
            </p>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">
              Office of the Controller of Examinations · Grade Record & Performance Card
            </p>
          </div>

          {/* Student Identifiers Grid */}
          <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-xs border border-slate-200 p-3 bg-slate-50/50">
            <div>
              <span className="text-slate-500">Student Name:</span>{' '}
              <strong className="text-slate-900">{student.name}</strong>
            </div>
            <div>
              <span className="text-slate-500">Roll Number:</span>{' '}
              <strong className="text-slate-900 font-mono">{student.rollNo}</strong>
            </div>
            <div>
              <span className="text-slate-500">Register / Adm No:</span>{' '}
              <strong className="text-slate-900 font-mono">{student.admissionNo}</strong>
            </div>
            <div>
              <span className="text-slate-500">Degree & Branch:</span>{' '}
              <strong className="text-slate-900">{student.courseName}</strong>
            </div>
            <div>
              <span className="text-slate-500">Semester & Section:</span>{' '}
              <strong className="text-slate-900">{student.semester} - Section {student.section}</strong>
            </div>
            <div>
              <span className="text-slate-500">Academic Standing:</span>{' '}
              <strong className="text-emerald-700">{student.academicStanding}</strong>
            </div>
          </div>

          {/* Current Semester Courses */}
          <div className="space-y-2">
            <div className="font-bold text-slate-900 uppercase tracking-wide text-[11px]">
              Continuous Internal Assessment & Grade Record ({currentRecord.semester})
            </div>
            <table className="w-full border-collapse border border-slate-300 text-left text-[11px]">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-300 text-slate-700 font-bold uppercase text-[10px]">
                  <th className="border border-slate-300 p-2">Course Code</th>
                  <th className="border border-slate-300 p-2">Course Title</th>
                  <th className="border border-slate-300 p-2 text-center">Credits</th>
                  <th className="border border-slate-300 p-2 text-center">CIA Total (50)</th>
                  <th className="border border-slate-300 p-2 text-center">Predicted Grade</th>
                  <th className="border border-slate-300 p-2 text-center">Result</th>
                </tr>
              </thead>
              <tbody>
                {currentRecord.subjects.map((sub) => (
                  <tr key={sub.code} className="border-b border-slate-200">
                    <td className="border border-slate-300 p-2 font-mono font-semibold">{sub.code}</td>
                    <td className="border border-slate-300 p-2">{sub.name}</td>
                    <td className="border border-slate-300 p-2 text-center font-mono">{sub.credits}</td>
                    <td className="border border-slate-300 p-2 text-center font-mono font-bold">{sub.internalTotal}</td>
                    <td className="border border-slate-300 p-2 text-center font-mono font-bold text-blue-700">{sub.predictedGrade}</td>
                    <td className="border border-slate-300 p-2 text-center font-semibold text-emerald-700">{sub.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Cumulative Performance Summary */}
          <div className="p-3 bg-slate-50 border border-slate-300 flex justify-between items-center text-xs">
            <div>
              <span className="text-slate-600 font-medium">Semester GPA (SGPA):</span>{' '}
              <strong className="font-mono text-slate-900 text-sm">{currentRecord.sgpa}</strong>
            </div>
            <div>
              <span className="text-slate-600 font-medium">Cumulative GPA (CGPA):</span>{' '}
              <strong className="font-mono text-slate-900 text-sm">8.72 / 10.00</strong>
            </div>
            <div>
              <span className="text-slate-600 font-medium">Standing Arrears:</span>{' '}
              <strong className="font-mono text-emerald-700 text-sm">NIL (Zero)</strong>
            </div>
          </div>

          {/* Institutional Signatures */}
          <div className="pt-8 flex justify-between items-end text-slate-700 text-[11px] border-t border-slate-200">
            <div className="text-center">
              <div className="font-semibold text-slate-900">Dr. K. Saravanan</div>
              <div className="text-slate-500">Class Advisor / Proctor</div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-slate-900">Dr. P. Kavitha</div>
              <div className="text-slate-500">Head of Department (CSBS)</div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-slate-900">Controller of Examinations</div>
              <div className="text-slate-500">Excel Autonomous Exam Cell</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
