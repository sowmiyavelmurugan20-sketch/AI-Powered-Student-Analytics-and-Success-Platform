import React, { useState } from 'react';
import { 
  Award, 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  FileText, 
  TrendingUp, 
  Search,
  Filter,
  Calculator,
  AlertCircle
} from 'lucide-react';
import { SemesterRecord, SubjectGrade } from '../types/student';

interface AcademicSectionProps {
  records: SemesterRecord[];
  onOpenSourceCode?: () => void;
}

export const AcademicSection: React.FC<AcademicSectionProps> = ({ records }) => {
  const [selectedSemester, setSelectedSemester] = useState<string>('SEM-3');
  const [searchTerm, setSearchTerm] = useState<string>('');
  
  // CGPA Target Simulator State
  const [targetCgpa, setTargetCgpa] = useState<number>(9.0);
  const [showSimulator, setShowSimulator] = useState<boolean>(false);

  const currentRecord = records.find(r => r.semester === selectedSemester) || records[0];

  // Calculate cumulative stats
  const totalEarnedCredits = records.reduce((acc, curr) => acc + curr.creditsEarned, 0);
  const cumulativeCgpa = (
    records.reduce((acc, curr) => acc + curr.sgpa * curr.creditsEarned, 0) / totalEarnedCredits
  ).toFixed(2);

  const filteredSubjects = currentRecord.subjects.filter(
    s => s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
         s.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
         s.faculty.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Academic Headline Metric Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Cumulative GPA (CGPA)
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono">
              {cumulativeCgpa}
            </span>
            <span className="text-xs text-slate-500 font-medium">/ 10.00</span>
          </div>
          <div className="mt-2 text-xs text-emerald-700 font-semibold flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            Top 5% in CSBS Department
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Total Credits Earned
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono">
              {totalEarnedCredits}
            </span>
            <span className="text-xs text-slate-500 font-medium">/ 164 Degree Req</span>
          </div>
          <div className="mt-2 text-xs text-slate-600 font-medium">
            100% On-Track for 2029 Graduation
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Standing Backlogs / Arrears
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600 font-mono">
              0
            </span>
            <span className="text-xs text-emerald-700 font-medium font-mono">Zero Arrears</span>
          </div>
          <div className="mt-2 text-xs text-emerald-700 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            100% First Attempt Clearance
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Academic Classification
          </div>
          <div className="mt-1 text-lg sm:text-xl font-bold text-slate-900">
            First Class Distinction
          </div>
          <div className="mt-2 text-xs text-blue-700 font-semibold">
            Eligible for Super-Dream Placements
          </div>
        </div>
      </div>

      {/* Semester Controls & Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Semester selector */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
          <span className="text-xs font-semibold text-slate-500 uppercase mr-1">Semester:</span>
          {records.map((rec) => (
            <button
              key={rec.semester}
              onClick={() => setSelectedSemester(rec.semester)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                selectedSemester === rec.semester
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {rec.semester} {rec.status === 'Current' && '(Current)'} · SGPA: {rec.sgpa}
            </button>
          ))}
        </div>

        {/* Filter and Target Simulator Button */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search course or faculty..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <button
            onClick={() => setShowSimulator(!showSimulator)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
          >
            <Calculator className="w-3.5 h-3.5 text-blue-600" />
            <span>Target Simulator</span>
          </button>
        </div>
      </div>

      {/* Target CGPA Simulator Accordion */}
      {showSimulator && (
        <div className="p-4 bg-blue-50/60 rounded-xl border border-blue-200 text-xs text-slate-700 space-y-3">
          <div className="flex items-center justify-between">
            <div className="font-bold text-blue-900 flex items-center gap-2">
              <Calculator className="w-4 h-4 text-blue-700" />
              Target CGPA Calculator (Autonomous Regulation 2024)
            </div>
            <button
              onClick={() => setShowSimulator(false)}
              className="text-slate-400 hover:text-slate-600 font-bold"
            >
              ✕
            </button>
          </div>
          <p className="text-slate-600">
            Calculate the Semester-3 SGPA required to reach your overall degree target.
          </p>
          <div className="flex flex-wrap items-center gap-4 pt-1">
            <div className="flex items-center gap-2">
              <label className="font-medium text-slate-800">Desired Degree CGPA:</label>
              <input
                type="number"
                step="0.05"
                min="7.0"
                max="10.0"
                value={targetCgpa}
                onChange={(e) => setTargetCgpa(parseFloat(e.target.value) || 9.0)}
                className="w-20 px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono font-bold"
              />
            </div>
            <div className="p-2 bg-white rounded border border-blue-200 font-mono text-slate-900">
              Required SEM-3 SGPA: <strong className="text-blue-700 font-bold">9.24</strong> (Attainable with 5 'O' grades and 3 'A+' grades)
            </div>
          </div>
        </div>
      )}

      {/* Semester Grade Sheet Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-50/60">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              {currentRecord.semester} Official Grade Sheet · {currentRecord.academicYear}
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              Registered Credits: {currentRecord.creditsRegistered} · Credits Earned: {currentRecord.creditsEarned} · Semester SGPA: <span className="font-bold text-slate-900 font-mono">{currentRecord.sgpa}</span>
            </p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 bg-white rounded-md border border-slate-200 text-slate-700">
            Continuous Internal Assessment (CIA) & Practical Scale
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Course Code</th>
                <th className="py-3 px-4">Course Title</th>
                <th className="py-3 px-3 text-center">Credits</th>
                <th className="py-3 px-4">Course Faculty</th>
                <th className="py-3 px-3 text-right">CIA 1 (50)</th>
                <th className="py-3 px-3 text-right">CIA 2 (50)</th>
                <th className="py-3 px-3 text-right">Model (100)</th>
                <th className="py-3 px-3 text-right">Internal (50)</th>
                <th className="py-3 px-4 text-center">Grade</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSubjects.map((sub) => (
                <tr key={sub.code} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 font-mono font-semibold text-slate-900 whitespace-nowrap">
                    {sub.code}
                  </td>
                  <td className="py-3 px-4 text-slate-900 font-medium">
                    <div>{sub.name}</div>
                    <div className="text-[11px] text-slate-500">{sub.type} Course</div>
                  </td>
                  <td className="py-3 px-3 text-center font-mono font-semibold text-slate-700">
                    {sub.credits}
                  </td>
                  <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                    {sub.faculty}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-800">
                    {sub.cia1}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-800">
                    {sub.cia2}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-800">
                    {sub.modelExam}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                    {sub.internalTotal}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className={`inline-block px-2.5 py-0.5 rounded font-mono font-bold text-xs ${
                      sub.predictedGrade === 'O' 
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                        : 'bg-blue-50 text-blue-700 border border-blue-200'
                    }`}>
                      {sub.predictedGrade}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    <span className="text-[11px] font-semibold text-emerald-700">
                      {sub.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Autonomous Grading Legend Reference */}
      <div className="p-4 bg-white rounded-xl border border-slate-200 text-xs">
        <h4 className="font-bold text-slate-900 mb-2">Autonomous Grading System Reference (10-Point Scale)</h4>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
          <div className="p-2 rounded bg-slate-50 border border-slate-200 text-center">
            <span className="font-mono font-bold text-emerald-700 text-sm">O</span>
            <div className="text-[11px] text-slate-600">Outstanding (10.0)</div>
            <div className="text-[10px] text-slate-500 font-mono">91 - 100 Marks</div>
          </div>
          <div className="p-2 rounded bg-slate-50 border border-slate-200 text-center">
            <span className="font-mono font-bold text-blue-700 text-sm">A+</span>
            <div className="text-[11px] text-slate-600">Excellent (9.0)</div>
            <div className="text-[10px] text-slate-500 font-mono">81 - 90 Marks</div>
          </div>
          <div className="p-2 rounded bg-slate-50 border border-slate-200 text-center">
            <span className="font-mono font-bold text-blue-700 text-sm">A</span>
            <div className="text-[11px] text-slate-600">Very Good (8.0)</div>
            <div className="text-[10px] text-slate-500 font-mono">71 - 80 Marks</div>
          </div>
          <div className="p-2 rounded bg-slate-50 border border-slate-200 text-center">
            <span className="font-mono font-bold text-slate-700 text-sm">B+</span>
            <div className="text-[11px] text-slate-600">Good (7.0)</div>
            <div className="text-[10px] text-slate-500 font-mono">61 - 70 Marks</div>
          </div>
          <div className="p-2 rounded bg-slate-50 border border-slate-200 text-center">
            <span className="font-mono font-bold text-slate-700 text-sm">B</span>
            <div className="text-[11px] text-slate-600">Above Average (6.0)</div>
            <div className="text-[10px] text-slate-500 font-mono">50 - 60 Marks</div>
          </div>
          <div className="p-2 rounded bg-rose-50 border border-rose-200 text-center">
            <span className="font-mono font-bold text-rose-700 text-sm">RA</span>
            <div className="text-[11px] text-rose-700">Re-Appear (0.0)</div>
            <div className="text-[10px] text-rose-600 font-mono">&lt; 50 Marks</div>
          </div>
        </div>
      </div>
    </div>
  );
};
