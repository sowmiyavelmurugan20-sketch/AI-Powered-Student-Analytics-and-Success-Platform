import React, { useState } from 'react';
import { 
  Users, 
  Target, 
  Zap, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  ChevronRight,
  Send,
  HelpCircle,
  TrendingUp,
  Brain,
  ShieldCheck
} from 'lucide-react';
import { StudentSegment, StudentProfile } from '../types/student';

interface SegmentationSectionProps {
  segments: StudentSegment[];
  currentStudent: StudentProfile;
}

export const SegmentationSection: React.FC<SegmentationSectionProps> = ({ 
  segments, 
  currentStudent 
}) => {
  const [selectedSegmentId, setSelectedSegmentId] = useState<string>(segments[0].id);
  const [actionTriggered, setActionTriggered] = useState<string | null>(null);

  const activeSegment = segments.find(s => s.id === selectedSegmentId) || segments[0];

  const handleTriggerIntervention = (planName: string) => {
    setActionTriggered(planName);
    setTimeout(() => setActionTriggered(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner for Bonus Feature */}
      <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              Institutional AI & Advisory Analytics
            </span>
            <span className="text-xs text-slate-500 font-mono">
              Autonomous Student Segmentation Engine
            </span>
          </div>
          <span className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            Active Accreditation Metric (NAAC Criteria 2.2.1)
          </span>
        </div>
        <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
          Targeted Student Segmentation & Faculty Intervention Matrix
        </h2>
        <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">
          Groups students into actionable cohorts based on multidimensional academic, placement readiness, and attendance metrics to deploy targeted, personalized faculty interventions.
        </p>
      </div>

      {/* 2x2 Matrix Visual Display */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {segments.map((seg) => {
          const isSelected = seg.id === activeSegment.id;
          return (
            <div
              key={seg.id}
              onClick={() => setSelectedSegmentId(seg.id)}
              className={`p-5 rounded-xl border text-xs cursor-pointer transition-all space-y-3 ${
                isSelected
                  ? 'bg-blue-50/40 border-blue-400 ring-2 ring-blue-500/20 shadow-xs'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">
                      {seg.name}
                    </span>
                    {seg.currentStudentBelongs && (
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded">
                        Current Student
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                    Criteria: {seg.criteria}
                  </div>
                </div>

                <span className="font-mono font-bold text-slate-700 bg-slate-100 px-2 py-1 rounded">
                  {seg.studentCountInCollege} Students
                </span>
              </div>

              <p className="text-slate-600 leading-relaxed">
                {seg.description}
              </p>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="font-semibold text-blue-700">
                  Intervention: {seg.recommendedAction}
                </span>
                <ChevronRight className={`w-4 h-4 text-slate-400 transition-transform ${isSelected ? 'rotate-90' : ''}`} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Detailed Intervention Playbook for the Selected Segment */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-900">
                Targeted Intervention Playbook: {activeSegment.name}
              </h3>
              {activeSegment.currentStudentBelongs && (
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {currentStudent.name} is mapped here
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Approved intervention strategies monitored by Class Advisor Dr. K. Saravanan.
            </p>
          </div>

          <span className="text-xs font-mono font-bold text-slate-700 bg-slate-50 px-2.5 py-1 rounded border border-slate-200 self-start sm:self-auto">
            Cohort Size: {activeSegment.studentCountInCollege} Students in Dept
          </span>
        </div>

        {actionTriggered && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Intervention Triggered: "<strong>{actionTriggered}</strong>" has been queued for faculty review!</span>
          </div>
        )}

        <div className="space-y-3">
          <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wide">
            Actionable Faculty Interventions
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {activeSegment.interventionPlan.map((action, idx) => (
              <div 
                key={idx}
                className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 flex flex-col justify-between space-y-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="font-bold text-slate-800 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-blue-600" />
                    Protocol 0{idx + 1}
                  </div>
                  <div className="text-slate-600 leading-relaxed">
                    {action}
                  </div>
                </div>

                <button
                  onClick={() => handleTriggerIntervention(action)}
                  className="w-full py-1.5 px-3 bg-white hover:bg-slate-100 text-slate-800 font-semibold rounded border border-slate-200 text-[11px] transition-colors flex items-center justify-center gap-1"
                >
                  <Send className="w-3 h-3 text-blue-600" />
                  Initiate Action
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Current Student Profile Analysis */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2">
          <div className="font-bold text-slate-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            Student Diagnostic Insight for {currentStudent.name} ({currentStudent.rollNo})
          </div>
          <p className="text-slate-700 leading-relaxed">
            With a <strong>8.72 CGPA</strong>, <strong>0 active backlogs</strong>, <strong>91.8% attendance</strong>, and an internal coding score of <strong>88/100</strong>, {currentStudent.name} sits comfortably in the highest Tier-1 Exemplar quadrant. Her profile indicates readiness for fast-track product interviews and student representation in state-level technical symposia.
          </p>
        </div>
      </div>
    </div>
  );
};
