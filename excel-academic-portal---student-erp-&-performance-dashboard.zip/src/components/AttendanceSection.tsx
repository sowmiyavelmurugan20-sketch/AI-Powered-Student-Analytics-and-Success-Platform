import React, { useState } from 'react';
import { 
  CheckCircle2, 
  AlertTriangle, 
  Calendar, 
  Clock, 
  Percent, 
  ShieldAlert, 
  FileCheck2,
  Send,
  HelpCircle
} from 'lucide-react';
import { AttendanceRecord, SubjectAttendance } from '../types/student';

interface AttendanceSectionProps {
  data: AttendanceRecord;
}

export const AttendanceSection: React.FC<AttendanceSectionProps> = ({ data }) => {
  const [selectedSubjectCode, setSelectedSubjectCode] = useState<string>(data.subjectWise[0]?.code || 'CB301');
  const [hypotheticalMissedClasses, setHypotheticalMissedClasses] = useState<number>(2);
  const [hypotheticalAttendedClasses, setHypotheticalAttendedClasses] = useState<number>(4);
  
  // OD Application Modal
  const [showOdModal, setShowOdModal] = useState<boolean>(false);
  const [odEvent, setOdEvent] = useState<string>('Smart India Hackathon 2026 Finals Preparation');
  const [odDates, setOdDates] = useState<string>('2026-10-14 to 2026-10-15');
  const [odSubmitted, setOdSubmitted] = useState<boolean>(false);

  const selectedSubject = data.subjectWise.find(s => s.code === selectedSubjectCode) || data.subjectWise[0];

  // Mathematical Simulator logic
  const simTotalConducted = selectedSubject.conducted + hypotheticalMissedClasses + hypotheticalAttendedClasses;
  const simTotalAttended = selectedSubject.attended + selectedSubject.odApproved + hypotheticalAttendedClasses;
  const simPercentage = simTotalConducted > 0 
    ? ((simTotalAttended / simTotalConducted) * 100).toFixed(1)
    : selectedSubject.percentage.toString();

  const handleOdSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setOdSubmitted(true);
    setTimeout(() => {
      setOdSubmitted(false);
      setShowOdModal(false);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {/* Attendance Headline Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Overall Portal Attendance
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono">
              {data.overallPercentage}%
            </span>
            <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Exam Eligible
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Min 75.0% required for Autonomous Hall Ticket
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Conducted vs Attended
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-blue-700">
              {data.totalAttended}
            </span>
            <span className="text-xs text-slate-500 font-medium">/ {data.totalConducted} Hours</span>
          </div>
          <div className="mt-2 text-xs text-slate-600 font-medium">
            Biometric verification active
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Approved On-Duty (OD)
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600">
              {data.totalOd}
            </span>
            <span className="text-xs text-slate-500 font-medium">Hours Counted</span>
          </div>
          <div className="mt-2 text-xs text-slate-600 font-medium">
            For Hackathons & Paper Presentations
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Safety Margin (Classes)
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              +78
            </span>
            <span className="text-xs text-slate-500 font-medium">Overall Buffer</span>
          </div>
          <div className="mt-2 text-xs text-emerald-700 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Zero Shortage Warnings
          </div>
        </div>
      </div>

      {/* Simulator Card & Quick OD Apply Trigger */}
      <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Percent className="w-4 h-4 text-blue-600" />
              Autonomous Attendance & Bunk Margin Simulator
            </h3>
            <p className="text-xs text-slate-500">
              Simulate upcoming classes to plan study leaves or predict post-event attendance ratios.
            </p>
          </div>
          <button
            onClick={() => setShowOdModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors whitespace-nowrap self-start sm:self-auto"
          >
            <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
            Apply On-Duty (OD)
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Select Course:</label>
            <select
              value={selectedSubjectCode}
              onChange={(e) => setSelectedSubjectCode(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium focus:outline-hidden focus:ring-1 focus:ring-blue-500"
            >
              {data.subjectWise.map(s => (
                <option key={s.code} value={s.code}>
                  {s.code}: {s.name.slice(0, 28)}... ({s.percentage}%)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Classes you might miss:</label>
            <input
              type="number"
              min="0"
              max="20"
              value={hypotheticalMissedClasses}
              onChange={(e) => setHypotheticalMissedClasses(Math.max(0, parseInt(e.target.value) || 0))}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono font-bold"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Classes you will attend:</label>
            <input
              type="number"
              min="0"
              max="30"
              value={hypotheticalAttendedClasses}
              onChange={(e) => setHypotheticalAttendedClasses(Math.max(0, parseInt(e.target.value) || 0))}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono font-bold"
            />
          </div>

          <div className="p-2.5 rounded-lg border bg-slate-50 border-slate-200">
            <div className="text-[11px] text-slate-500 font-medium">Projected Attendance:</div>
            <div className="text-base font-extrabold font-mono text-slate-900 mt-0.5 flex items-baseline gap-1.5">
              <span>{simPercentage}%</span>
              <span className={`text-[11px] font-semibold ${
                parseFloat(simPercentage) >= 75 ? 'text-emerald-700' : 'text-rose-700'
              }`}>
                {parseFloat(simPercentage) >= 75 ? '(Above 75% Cutoff)' : '(Below 75% Risk!)'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Subject-Wise Attendance Breakdown Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-50/60">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Subject-Wise Attendance Breakdown (SEM-3)
            </h3>
            <p className="text-xs text-slate-500">
              Real-time records synchronized from Excel Autonomous Camu ERP Biometrics.
            </p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 bg-white rounded-md border border-slate-200 text-slate-700">
            Cutoff Threshold: 75.0%
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Subject</th>
                <th className="py-3 px-4">Faculty In-Charge</th>
                <th className="py-3 px-3 text-right">Conducted</th>
                <th className="py-3 px-3 text-right">Attended</th>
                <th className="py-3 px-3 text-right">OD</th>
                <th className="py-3 px-4 text-center">Attendance %</th>
                <th className="py-3 px-4 text-center">Safe Buffer</th>
                <th className="py-3 px-4 text-center">Eligibility</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {data.subjectWise.map((sub) => (
                <tr key={sub.code} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4">
                    <span className="font-mono font-semibold text-slate-900 mr-2">{sub.code}</span>
                    <span className="font-medium text-slate-800">{sub.name}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                    {sub.faculty}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-700">
                    {sub.conducted}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                    {sub.attended}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-700 font-semibold">
                    +{sub.odApproved}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <span className="font-mono font-bold text-slate-900 text-xs">
                        {sub.percentage}%
                      </span>
                      <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                        <div 
                          className="bg-emerald-600 h-1.5 rounded-full" 
                          style={{ width: `${Math.min(100, sub.percentage)}%` }} 
                        />
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap font-mono text-slate-600">
                    +{sub.canBunkClasses} Classes
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      Eligible
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Biometric Daily Class Log */}
      <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Clock className="w-4 h-4 text-slate-600" />
          Recent Daily Classroom & Biometric Verification Logs
        </h3>

        <div className="space-y-3">
          {data.recentLogs.map((log) => (
            <div key={log.date} className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-800 font-mono">{log.date} ({log.day})</span>
                <span className="text-[11px] text-slate-500 font-medium">Class Attendance Verified by Faculty</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                {log.periods.map((p) => (
                  <div 
                    key={p.period} 
                    className={`p-2 rounded text-center border text-xs ${
                      p.status === 'Present' 
                        ? 'bg-white border-slate-200 text-slate-800'
                        : p.status === 'OD'
                        ? 'bg-blue-50 border-blue-200 text-blue-800'
                        : 'bg-rose-50 border-rose-200 text-rose-800'
                    }`}
                  >
                    <div className="text-[10px] text-slate-500 font-medium">Period {p.period}</div>
                    <div className="font-semibold truncate" title={p.subject}>{p.subject}</div>
                    <div className={`text-[10px] font-bold mt-0.5 font-mono ${
                      p.status === 'Present' ? 'text-emerald-700' : p.status === 'OD' ? 'text-blue-700' : 'text-rose-700'
                    }`}>
                      {p.status}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* On-Duty (OD) Modal */}
      {showOdModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 p-5 space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-sm font-bold text-slate-900">
                Apply for On-Duty (OD) Regularization
              </h4>
              <button
                onClick={() => setShowOdModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            {odSubmitted ? (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 text-center space-y-1">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 mx-auto" />
                <div className="font-bold">OD Application Forwarded to Class Advisor</div>
                <div className="text-slate-600">Once approved by Dr. K. Saravanan, attendance will be credited automatically.</div>
              </div>
            ) : (
              <form onSubmit={handleOdSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Activity / Event Name:</label>
                  <input
                    type="text"
                    required
                    value={odEvent}
                    onChange={(e) => setOdEvent(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Date Range (Classes Affected):</label>
                  <input
                    type="text"
                    required
                    value={odDates}
                    onChange={(e) => setOdDates(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Upload Certificate / Invitation Proof:</label>
                  <div className="border-2 border-dashed border-slate-200 rounded-lg p-3 text-center text-slate-500 hover:border-blue-400 cursor-pointer">
                    Click to attach approval letter (.pdf, max 5MB)
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowOdModal(false)}
                    className="px-3 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-xs"
                  >
                    Submit to Advisor
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
