import React from 'react';
import { 
  Building2, 
  User, 
  FileCode2, 
  Printer, 
  Bell, 
  ShieldCheck, 
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { StudentProfile } from '../types/student';

interface HeaderProps {
  student: StudentProfile;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenProfile: () => void;
  onOpenSourceCode: () => void;
  onPrintTranscript: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  student,
  activeTab,
  onTabChange,
  onOpenProfile,
  onOpenSourceCode,
  onPrintTranscript,
}) => {
  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'academic', label: 'Academic & Grades' },
    { id: 'attendance', label: 'Attendance (91.8%)' },
    { id: 'placement', label: 'Placement & PAT' },
    { id: 'lms', label: 'LMS & Assignments' },
    { id: 'skills', label: 'Skills & Honors' },
    { id: 'segmentation', label: 'Student Segmentation' },
    { id: 'feedback', label: 'Feedback & Mentoring' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs no-print">
      {/* Top Institutional Identity Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 border-b border-slate-100">
          {/* Institution & Camu Logo Brand Zone */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg overflow-hidden border border-slate-200 bg-white shrink-0 shadow-xs flex items-center justify-center">
              <img 
                src={student.collegeLogoUrl} 
                alt="College Crest" 
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight leading-tight">
                  {student.college}
                </h1>
                <span className="hidden md:inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  NAAC A+ Autonomous
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Academic Management Portal · Regulation 2024 · B.Tech CSBS
              </p>
            </div>
          </div>

          {/* Quick Header Tools & Profile Trigger */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* View Source Code Button (Directly satisfies user prompt) */}
            <button
              onClick={onOpenSourceCode}
              title="View modular clean TypeScript/React source code"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors whitespace-nowrap"
            >
              <FileCode2 className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden sm:inline">Source Code</span>
            </button>

            {/* Print Official Summary Button */}
            <button
              onClick={onPrintTranscript}
              title="Print official academic student record"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors whitespace-nowrap"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden sm:inline">Print Card</span>
            </button>

            {/* Student ID Badge & Drawer Toggle */}
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-2.5 pl-2 pr-3 py-1 rounded-lg border border-slate-200 hover:border-slate-300 hover:bg-slate-50/80 transition-colors text-left"
              title="Click to view full Camu Student Profile & Details"
            >
              <div className="w-8 h-8 rounded-full overflow-hidden border border-slate-200 bg-slate-100 shrink-0">
                <img 
                  src={student.avatarUrl} 
                  alt={student.name} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="hidden sm:block">
                <div className="text-xs font-bold text-slate-900 leading-tight">
                  {student.name}
                </div>
                <div className="text-[11px] text-slate-500 font-mono">
                  {student.rollNo} · {student.semester}
                </div>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
            </button>
          </div>
        </div>

        {/* Primary Functional Tabs */}
        <nav className="flex items-center gap-1 overflow-x-auto py-2 scrollbar-none" aria-label="Portal Navigation">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
